const cookieAmount = 0
const gmPrice = 50
const farmPrice = 500

function cookieClick() {
    const amount = document.getElementById('amt')
    const cookieAmount = cookieAmount + 1
    console.log(cookieAmount)
}